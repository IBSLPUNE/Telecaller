import { NgModule } from '@angular/core';
/*import { AgentPipe } from './agent/agent';
import { EnquirynamePipe } from './enquiryname/enquiryname';
import { BranchPipe } from './branch/branch';
import { SchemePipe } from './scheme/scheme';
import { EmpnamePipe } from './empname/empname';
import { EmpdatePipe } from './empdate/empdate';*/
@NgModule({
	declarations: [/*AgentPipe,EnquirynamePipe BranchPipe SchemePipe EmpnamePipe EmpdatePipe*/],
	imports: [],
	exports: [/*AgentPipe,EnquirynamePipe BranchPipe SchemePipe EmpnamePipe EmpdatePipe*/]
})
export class PipesModule {}
