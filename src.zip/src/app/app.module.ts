import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HttpClientModule } from '@angular/common/http';
 import { HttpModule } from '@angular/http';
 import { IonicStorageModule } from '@ionic/storage';

import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';

import { LoginPage } from '../pages/login/login';
import { MenuPage } from '../pages/menu/menu';
import { CompanyPage } from '../pages/company/company';
import { BranchPage } from '../pages/branch/branch';
import { EmployeeListPage } from '../pages/employee-list/employee-list';
import { EmployeeListDetailPage } from '../pages/employee-list-detail/employee-list-detail';
import { EnquiryListPage } from '../pages/enquiry-list/enquiry-list';
import { EnquiryListDetailPage } from '../pages/enquiry-list-detail/enquiry-list-detail';
import { SchemesListPage } from '../pages/schemes-list/schemes-list';
import { SchemesListDetailPage } from '../pages/schemes-list-detail/schemes-list-detail';

import { DatePickerModule } from 'ion-datepicker';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AuthServiceProvider } from '../providers/auth-service/auth-service';

@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    LoginPage,
    MenuPage,
    CompanyPage,
    BranchPage,
    EmployeeListPage,
    EnquiryListPage,
    EnquiryListDetailPage,
    SchemesListPage,
    SchemesListDetailPage,
    EmployeeListDetailPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule,
    IonicStorageModule.forRoot(),
    HttpClientModule,
    DatePickerModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    LoginPage,
    MenuPage,
    CompanyPage,
    BranchPage,
    EmployeeListPage,
    EnquiryListPage,
    EnquiryListDetailPage,
    SchemesListPage,
    SchemesListDetailPage,
    EmployeeListDetailPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthServiceProvider
  ]
})
export class AppModule {}
