import { App } from 'ionic-angular';
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';

import { LoginPage } from '../../pages/login/login';
/*
  Generated class for the AuthServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class AuthServiceProvider {

     public serverIP ='http://192.168.24.149:3000'; 

  public apiUrl_user_auths = this.serverIP + '/api/user_auths/';   //api server

  constructor(public http: Http, public _app: App) {
    console.log('Hello AuthServiceProvider Provider');
  }
   login(credentials) {
        return new Promise((resolve, reject) => {
            let headers = new Headers();
            let body = new FormData();
            body.append('email', credentials.username);
            body.append('password', credentials.password);

            this.http.post(this.apiUrl_user_auths + 'user_sign_in', body, { headers: headers })
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
      Logout() {
        localStorage.removeItem('member_id');
        this._app.getRootNavs()[0].setRoot(LoginPage);
    }

      getCompanyProfile() {
        return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'company_profile')
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
    getBranchDetails(){
       return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'branch_list')
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });

    }
       getBloodGroupType() {
        return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'blood_group_list')
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
     getCountyType() {
        return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'contries_list')
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
      getStateType(county_type) {
        return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'state_list?country_id=' + county_type)
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
     getDistrictType(state_type) {
        return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'districts_list?state_id=' + state_type)
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
     saveEmployeeRequest(EmployeeReq) {
        return new Promise((resolve, reject) => {
            let headers = new Headers();
            let body = new FormData();
         
            body.append('code', EmployeeReq.code);
            body.append('prefix', EmployeeReq.prefix);
            body.append('first_name', EmployeeReq.first_name);
            body.append('middle_name', EmployeeReq.middle_name);
            body.append('last_name', EmployeeReq.last_name);
            body.append('gender', EmployeeReq.gender); 
            body.append('email', EmployeeReq.email);
            body.append('contact_no', EmployeeReq.contact_no);
            body.append('blood_group', EmployeeReq.blood_group);
            body.append('date_of)birth', EmployeeReq.selectedDate);
            body.append('address', EmployeeReq.address);
            body.append('pin_code', EmployeeReq.pin_code);
            body.append('county', EmployeeReq.county);
            body.append('state', EmployeeReq.state);
            body.append('district', EmployeeReq.district);
            body.append('city', EmployeeReq.city);
            body.append('adhar_no', EmployeeReq.adhar_no);
            body.append('status', EmployeeReq.status);
           

            this.http.post(this.apiUrl_user_auths + 'create_employee1', body, { headers: headers })
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
    saveEnquiryRequest(EnquiryReq){
     return new Promise((resolve, reject) => {
            let headers = new Headers();
            let body = new FormData();
         
            body.append('first_name', EnquiryReq.first_name);
            body.append('middle_name', EnquiryReq.middle_name);
            body.append('last_name', EnquiryReq.last_name);
            body.append('email', EnquiryReq.email);
            body.append('mobile_no', EnquiryReq.mobile_no);
            body.append('address', EnquiryReq.address);
            body.append('place', EnquiryReq.place);
            body.append('description', EnquiryReq.description);
            body.append('user_id', EnquiryReq.member_id);
            

            this.http.post(this.apiUrl_user_auths + 'create_enquiry', body, { headers: headers })
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });

    }
    saveSchemeRequest(SchemeReq){
     return new Promise((resolve, reject) => {
            let headers = new Headers();
            let body = new FormData();
         
            body.append('scheme_type', SchemeReq.type);
            body.append('name', SchemeReq.name);
            body.append('budget', SchemeReq.budget);
            body.append('down_payment', SchemeReq.down_payment);
            body.append('installment', SchemeReq.installment);
            body.append('installment_amount', SchemeReq.installment_amount);
            body.append('intrest', SchemeReq.intrest);
            body.append('from_date', SchemeReq.from_date);
            body.append('to_date', SchemeReq.to_date);
            

            this.http.post(this.apiUrl_user_auths + 'create_scheme', body, { headers: headers })
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });


    }
    getEnquiryList() {
        return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'enquiry_list')
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
    getEmployeeList(){
     return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'employee_list')
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
    getSchemeList(){
    return new Promise((resolve, reject) => {
            this.http.get(this.apiUrl_user_auths + 'schemes_list')
                .subscribe(res => {
                    resolve(res.json());
                }, (err) => {
                    reject(err);
                });
        });
    }
}
