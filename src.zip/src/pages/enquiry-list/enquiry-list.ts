import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController, AlertController, PopoverController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { EnquiryListDetailPage } from '../enquiry-list-detail/enquiry-list-detail';
/**
 * Generated class for the EnquiryListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-enquiry-list',
  templateUrl: 'enquiry-list.html',
})
export class EnquiryListPage {
  loading:any;
  enquiry_data: any;

 constructor(public navCtrl: NavController, public navParams: NavParams, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, private modalCtrl: ModalController, public alertCtrl: AlertController, public popoverCtrl: PopoverController) {
      this.getEnquiryList();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EnquiryListPage');
  }
   showNewEnquiryRequest(){
      var EnquiryRequestPagemodalPage = this.modalCtrl.create('EnquiryPage');
      
       
        EnquiryRequestPagemodalPage.onDidDismiss(data => {
        this.getEnquiryList();
    
           
        });
        EnquiryRequestPagemodalPage.present();
}
   getEnquiryList(){
        this.showLoader();
            this.authService.getEnquiryList().then((result) => {
            this.loading.dismiss();
            this.enquiry_data = result;
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
    showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });
        toast.present();
    }
    showModalDialog(enquiry_req_data)
    {
      var data = {
            id: enquiry_req_data.id,
            mobile_no: enquiry_req_data.mobile_no,
            name_first: enquiry_req_data.name_first,
            middle_name: enquiry_req_data.middle_name,
            last_name: enquiry_req_data.last_name,
            address: enquiry_req_data.address,
            email: enquiry_req_data.email,
            user_id: enquiry_req_data.user_id,
            place: enquiry_req_data.place
        };
       
        var DetailsmodalPage = this.popoverCtrl.create(EnquiryListDetailPage, data, { cssClass: 'clsPopup' });
        DetailsmodalPage.present();
        this.getEnquiryList();

    }
}
