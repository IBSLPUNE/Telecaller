import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, ToastController, ViewController  } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
/**
 * Generated class for the EnquiryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-enquiry',
  templateUrl: 'enquiry.html',
})
export class EnquiryPage {

  loading: any;
  
   
   firstName: any;
   middleName: any;
   lastName: any;
   MobileNo: any;
   Email: any;
   Address: any;
   Place: any;
   description: any;

   

   EnquiryReq = { first_name: '', middle_name: '', last_name: '', email: '', mobile_no: '', address: '', place:'', member_id:'', description:''}

   constructor(public navCtrl: NavController, public navParams: NavParams, private alertCtrl: AlertController, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, public viewCtrl: ViewController) {

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EnquiryPage');
 
  }
  
    compareFn(option1: any, option2: any) {
        return option1.value === option2.value;
    }

   saveEnquiryRequest(){
         
        if (this.MobileNo == undefined) {
             this.showAlert('Message', 'Please Select Mobile No.');
            return;
        }
        if (this.firstName == undefined) {
             this.showAlert('Message', 'Please Select First Name.');
            return;
        }
      
     this.showLoader();
        this.EnquiryReq.first_name = this.firstName;
        this.EnquiryReq.middle_name = this.middleName;
        this.EnquiryReq.last_name = this.lastName;
        this.EnquiryReq.email = this.Email;
        this.EnquiryReq.mobile_no = this.MobileNo;
        this.EnquiryReq.address = this.Address;
        this.EnquiryReq.place = this.Place;
        this.EnquiryReq.description = this.description;
        this.EnquiryReq.member_id = localStorage.getItem('member_id');
  
     
        this.authService.saveEnquiryRequest(this.EnquiryReq).then((result) => {
            this.loading.dismiss();

           this.showAlert('success', 'Created successfully');
                this.closeModal();
          }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });

    }
     public closeModal() {

        this.viewCtrl.dismiss();
    }
     showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });

        toast.present();
    }

    showAlert(title, text) {
        //this.loading.dismiss();

        let alert = this.alertCtrl.create({
            title: title,
            subTitle: text,
            buttons: ['OK']
        });
        alert.present();
    }
 

}
