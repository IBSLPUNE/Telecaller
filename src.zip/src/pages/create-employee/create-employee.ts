import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, ToastController, ViewController  } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import moment from 'moment';
/**
 * Generated class for the CreateEmployeePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-create-employee',
  templateUrl: 'create-employee.html',
})
export class CreateEmployeePage {
loading: any;

   blood_type_data: Array<{ value: string, text: string }> = [];
   blood_group: any;
   bloodtype: any;

   county_type_data: Array<{ value: string, text: string }> = [];
   county: any;
   countytype: any;

   state_type_data: Array<{ value: string, text: string }> = [];
   state: any;
   statetype: any;

   district_type_data: Array<{ value: string, text: string }> = [];
   district: any;
   districttype: any;

   date_Min: Date = new Date();
   date_Max: Date = new Date();
   selectedDate: Date = new Date();

   Code: any;
   firstName: any;
   middleName: any;
   lastName: any;
  
   Email: any;
   ContactNo: any;
  
  
   Address: any;
   pinCode: any;
   City: any;
   AdharCard: any;
  
   gender: any;
   gender_data: any;
   
   prefix: any;
   prefix_data: any;

   EmployeeReq = { code: '', prefix: '', first_name: '', middle_name: '', last_name: '', gender: '', email: '', contact_no: '', blood_group: '', selectedDate: '', address: '', pin_code: '', county: '', state: '', district: '', city: '', adhar_no: '', status:'active' }

//employee_id: '', manager1_id: '', manager2_id: '',
   constructor(public navCtrl: NavController, public navParams: NavParams, private alertCtrl: AlertController, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, public viewCtrl: ViewController) {
     // this.getBloodGroupType();
      this.prefix_data = [
          //  { text: 'Select prefix Type', value: '' },
            { text: 'Mr', value: 'Mr' },  
            { text: 'Miss', value: 'Miss' }
            
        ];
         this.prefix = { text: 'Mr', value: 'Mr' };

      this.selectedDate = new Date();
      this.date_Min.setMonth(-500, 1);
      this.date_Max.setFullYear((new Date()).getFullYear() + 1);
  }

  ionViewDidLoad() {
   // console.log('ionViewDidLoad CreateEmployeePage');


     this.gender_data = [
          //  { text: 'Select Gender Type', value: '' },
            { text: 'Male', value: 'Male' },  
            { text: 'Female', value: 'Female' }
            
        ];
         this.gender = { text: 'Male', value: 'Male' };

  }
  
   dateChanged() {
       // this.getEmployeePlanList();
    }

    setDate(date: Date) {
        this.selectedDate = date;
        this.dateChanged();
    }
    compareFn(option1: any, option2: any) {
        return option1.value === option2.value;
    }

      getBloodGroupType() {
        this.showLoader();
        this.authService.getBloodGroupType().then((result) => {
           // this.loading.dismiss();

            this.bloodtype = result;

            this.blood_type_data.push({ value: '', text: 'Select Blood Group' });

            for (let i = 0; i < this.bloodtype.length; i++) {
                this.blood_type_data.push({ value: this.bloodtype[i].id, text: this.bloodtype[i].name });
            }

            this.blood_group = { text: 'Select Blood Group', value: '' };
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
      }
     getCountyType() {
       // this.showLoader();
        this.authService.getCountyType().then((result) => {
            this.loading.dismiss();

            this.countytype = result;

            this.county_type_data.push({ value: '', text: 'Select County' });

            for (let i = 0; i < this.countytype.length; i++) {
                this.county_type_data.push({ value: this.countytype[i].id, text: this.countytype[i].name });
            }

            this.county = { text: 'Select County', value: '' };

            //this.getStateType();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
     getStateType() {
        //this.showLoader();
        this.authService.getStateType(this.county.value).then((result) => {
           // this.loading.dismiss();

            this.statetype = result;

            this.state_type_data.push({ value: '', text: 'Select State' });

            for (let i = 0; i < this.statetype.length; i++) {
                this.state_type_data.push({ value: this.statetype[i].id, text: this.statetype[i].name });
            }

            this.state = { text: 'Select State', value: '' };

            //this.getDistrictType();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
     getDistrictType() {
      //  this.showLoader();
        this.authService.getDistrictType(this.state.value).then((result) => {
           // this.loading.dismiss();

            this.districttype = result;

            this.district_type_data.push({ value: '', text: 'Select District' });

            for (let i = 0; i < this.districttype.length; i++) {
                this.district_type_data.push({ value: this.districttype[i].id, text: this.districttype[i].name });
            }

            this.district = { text: 'Select District', value: '' };

           
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
      
   

    saveEmployeeRequest(){

  
          if (this.firstName == undefined) {
             this.showAlert('Message', 'Please Select First Name.');
            return;
        }
          if (this.lastName == undefined) {
             this.showAlert('Message', 'Please Select Last Name.');
            return;
        }

        this.showLoader();
       
        this.EmployeeReq.code = this.Code;
        this.EmployeeReq.prefix = this.prefix.value;
        this.EmployeeReq.first_name = this.firstName;
        this.EmployeeReq.middle_name = this.middleName;
        this.EmployeeReq.last_name = this.lastName;
        this.EmployeeReq.gender = this.gender.value;
        this.EmployeeReq.email = this.Email;
        this.EmployeeReq.contact_no = this.ContactNo;
        this.EmployeeReq.blood_group = this.blood_group;
        this.EmployeeReq.selectedDate = moment(this.selectedDate.toString()).format('YYYY-MM-DD');
        this.EmployeeReq.address = this.Address;
        this.EmployeeReq.pin_code = this.pinCode;
        this.EmployeeReq.county = this.county;
        this.EmployeeReq.state = this.state;
        this.EmployeeReq.district = this.district;
        this.EmployeeReq.city = this.City;
        this.EmployeeReq.adhar_no = this.AdharCard;

        this.authService.saveEmployeeRequest(this.EmployeeReq).then((result) => {
            this.loading.dismiss();

           this.showAlert('success', 'Employee Created successfully');
                this.closeModal();
          }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });

    }
     public closeModal() {

        this.viewCtrl.dismiss();
    }
     showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });

        toast.present();
    }

    showAlert(title, text) {
        //this.loading.dismiss();

        let alert = this.alertCtrl.create({
            title: title,
            subTitle: text,
            buttons: ['OK']
        });
        alert.present();
    }
 
}
