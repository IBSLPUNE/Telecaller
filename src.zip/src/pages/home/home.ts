import { Component } from '@angular/core';
import { NavController, LoadingController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { MenuPage } from '../menu/menu';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
loading:any;

  constructor(public navCtrl: NavController, public loadingCtrl: LoadingController) {
   this.settimeout();
  }
   settimeout() {
        setTimeout(() => {
            
              if (localStorage.getItem('member_id') == undefined) {
                this.navCtrl.setRoot(LoginPage);
            }
         
                else {
           
                    this.navCtrl.setRoot(MenuPage);
           
                }

        }, 2500);
    }

    showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

}
