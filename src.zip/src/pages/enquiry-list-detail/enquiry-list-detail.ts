import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the EnquiryListDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-enquiry-list-detail',
  templateUrl: 'enquiry-list-detail.html',
})
export class EnquiryListDetailPage {

   enquiry_req_data = {
			id: '',
			mobile_no: '',
			name_first: '',
			middle_name : '',
			last_name: '',
			address: '',
			place: '',
			email: '',
			user_id: ''
			};

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl : ViewController) {
  }

  ionViewDidLoad() {
        this.enquiry_req_data.id = this.navParams.get('id');
	    this.enquiry_req_data.mobile_no = this.navParams.get('mobile_no');
		this.enquiry_req_data.name_first = this.navParams.get('name_first');
	    this.enquiry_req_data.middle_name = this.navParams.get('middle_name');
		this.enquiry_req_data.last_name = this.navParams.get('last_name');
		this.enquiry_req_data.address = this.navParams.get('address');
		this.enquiry_req_data.place = this.navParams.get('place');
		this.enquiry_req_data.email = this.navParams.get('email');
		this.enquiry_req_data.user_id = this.navParams.get('user_id');
	
    console.log('ionViewDidLoad EnquiryListDetailPage');
  }
  public closeModal(){
  this.viewCtrl.dismiss();
  }


}
