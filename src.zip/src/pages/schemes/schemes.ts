import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, ToastController, ViewController  } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import moment from 'moment';
/**
 * Generated class for the SchemesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-schemes',
  templateUrl: 'schemes.html',
})
export class SchemesPage {
   loading: any;

    from_date_Min: Date = new Date();
    from_date_Max: Date = new Date();
    fromDate: Date = new Date();

    to_date_Min: Date = new Date();
    to_date_Max: Date = new Date();
    toDate: Date = new Date();

    Date_Min: Date = new Date();
    Date_Max: Date = new Date();
    Date: Date = new Date();

    Type: any;
    Name: any;
    Budget: any;
    Down_Payment: any;
    Installment: any;
    Installment_Amount: any;
    Intrest: any;
  
   SchemeReq = { type: '', name: '', budget: '', down_payment: '', installment: '',installment_amount: '', intrest: '', from_date: '', to_date: '' }


   constructor(public navCtrl: NavController, public navParams: NavParams, private alertCtrl: AlertController, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, public viewCtrl: ViewController) {
    
      this.fromDate = new Date();
        this.from_date_Min.setMonth(0, 1);
        this.from_date_Max.setFullYear((new Date()).getFullYear() + 5);

        this.toDate = new Date();
        this.to_date_Min.setMonth(0, 1);
        this.to_date_Max.setFullYear((new Date()).getFullYear() + 5);

        this.Date = new Date();
        this.Date_Min.setMonth(0, 1);
        this.Date_Max.setFullYear((new Date()).getFullYear() + 5);
  }

  ionViewDidLoad() {
   
  }
  
  

    setDate(date: Date, sDate: string) {
        if (sDate == 'fromDt') {
            this.fromDate = date;
            this.toDate = date;
            
        }
        if (sDate == 'toDt') {
            this.toDate = date;
        }
        if (sDate == 'Dt') {
            this.Date = date;
        }
    }
   
    saveSchemeRequest(){

   
       if (this.Type == undefined) {
             this.showAlert('Message', 'Please Select type.');
            return;
        }
     this.showLoader();

       
        this.SchemeReq.type = this.Type;
        this.SchemeReq.name = this.Name;
        this.SchemeReq.budget = this.Budget;
        this.SchemeReq.down_payment = this.Down_Payment;
        this.SchemeReq.installment = this.Installment;
        this.SchemeReq.intrest = this.Intrest;
        this.SchemeReq.installment_amount = this.Installment_Amount;
        
        this.SchemeReq.from_date = moment(this.fromDate.toString()).format('YYYY-MM-DD');
        this.SchemeReq.to_date = moment(this.toDate.toString()).format('YYYY-MM-DD');
  
     
        this.authService.saveSchemeRequest(this.SchemeReq).then((result) => {
            this.loading.dismiss();

           this.showAlert('success', 'Created successfully');
                this.closeModal();
          }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });

    }
     public closeModal() {

        this.viewCtrl.dismiss();
    }
     showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });

        toast.present();
    }

    showAlert(title, text) {
        //this.loading.dismiss();

        let alert = this.alertCtrl.create({
            title: title,
            subTitle: text,
            buttons: ['OK']
        });
        alert.present();
    }

}
