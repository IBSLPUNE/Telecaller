import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, ToastController, App } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { CompanyPage } from '../company/company';
import { BranchPage } from '../branch/branch';
import { EmployeeListPage } from '../employee-list/employee-list';
import { EnquiryListPage } from '../enquiry-list/enquiry-list';
import { SchemesListPage } from '../schemes-list/schemes-list';


/**
 * Generated class for the MenuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html',
})
export class MenuPage {

 constructor(public navCtrl: NavController, public navParams: NavParams, private alertCtrl: AlertController, public _app: App, private toastCtrl: ToastController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MenuPage');
  }
   gotoAnotherPage(clickedOn) {
      
        
         if (clickedOn == 'CompanyProfile') {
            this.navCtrl.push(CompanyPage);
        }
          if (clickedOn == 'Logout') {
            localStorage.removeItem('member_id');
            this._app.getRootNavs()[0].setRoot(LoginPage); //this._app.getRootNav().setRoot(LoginPage);
        }
         if (clickedOn == 'Branch') {
            this.navCtrl.push(BranchPage);
        }
         if (clickedOn == 'CreateEmployee') {
            this.navCtrl.push(EmployeeListPage);
        }
         if (clickedOn == 'Enquiry') {
            this.navCtrl.push(EnquiryListPage);
        } 
        if (clickedOn == 'Schemes') {
            this.navCtrl.push(SchemesListPage);
        }
          }
    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });
        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });
        toast.present();
    }

    showAlert(title, text) {
        let alert = this.alertCtrl.create({
            title: title,
            subTitle: text,
            buttons: ['OK']
        });
        alert.present();
    }

}
